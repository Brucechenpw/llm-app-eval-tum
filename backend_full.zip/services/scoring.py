
GRADE = {
    "A+":1,"A":1,"A-":0.95,"B+":0.9,"B":0.8,"B-":0.75,"C+":0.7,"C":0.6
}
CURRICULUM = {
    "Mathematics": ["Calculus", "Linear Algebra", "Probability"],
    "Algorithms": ["Advanced Algorithms", "Data Structures"],
    "Software Engineering": ["Software Design", "Testing", "Agile"]
}

def score_tracks(courses: list[dict]):
    scores, expl = {}, {}
    for track, reqs in CURRICULUM.items():
        matched = [c for c in courses if any(r.lower() in c['course_name'].lower() for r in reqs)]
        pts = sum(GRADE.get(c.get('grade','').upper(), 0.7) for c in matched)
        scores[track] = round(100 * pts / len(reqs), 2)
        expl[track] = "Matched: " + ", ".join(c['course_name'] for c in matched) if matched else "No match."
    return scores, expl
