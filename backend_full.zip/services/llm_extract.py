
import os, json, openai

openai.api_key = os.getenv("OPENAI_API_KEY")

PROMPT = (
    "You are an academic-records parser.\n\n"
    "Return ONLY a JSON array where each element has:\n"
    '  • \"course_name\"\n'
    '  • \"grade\" (\"\" if not present)\n\n'
    "Example:\n"
    "[\n"
    "  {{ \"course_name\": \"Advanced Algorithms\", \"grade\": \"A\" }},\n"
    "  {{ \"course_name\": \"Linear Algebra\",      \"grade\": \"B+\" }}\n"
    "]\n\n"
    "Text to parse:\n\n"
    "{snippet}"
)

def extract_courses(raw_text: str, model: str = "gpt-3.5-turbo") -> list[dict]:
    snippet = raw_text[:3500]
    resp = openai.ChatCompletion.create(
        model=model,
        temperature=0,
        messages=[{"role":"user","content":PROMPT.format(snippet=snippet)}],
        max_tokens=800
    )
    content = resp.choices[0].message.content.strip()
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        return []
