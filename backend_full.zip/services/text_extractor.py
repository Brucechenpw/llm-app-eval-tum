
import os, pdfplumber, pytesseract
from PIL import Image

def extract_text(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        with pdfplumber.open(path) as pdf:
            return "\n".join(p.extract_text() or "" for p in pdf.pages)
    if ext in {".png", ".jpg", ".jpeg"}:
        return pytesseract.image_to_string(Image.open(path))
    if ext == ".txt":
        with open(path, "r", encoding="utf-8", errors="ignore") as fh:
            return fh.read()
    return ""
