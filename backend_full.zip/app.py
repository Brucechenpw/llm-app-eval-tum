
from flask import Flask, render_template, request, redirect, url_for, session, flash
import os, uuid, datetime, json
from dotenv import load_dotenv

from services.text_extractor import extract_text
from services.llm_extract    import extract_courses
from services.scoring        import score_tracks

load_dotenv()
app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "demo-secret")
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 5 MB

UPLOAD_FOLDER = "uploads"
RESULT_FOLDER = "results"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

ALLOWED = {
    "cv_file": {".pdf", ".doc", ".docx", ".txt"},
    "transcript_file": {".pdf", ".png", ".jpg", ".jpeg", ".txt"},
    "essay_file": {".pdf", ".doc", ".docx", ".txt"}
}

@app.route("/")
def root():
    return redirect(url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        if not email or "@" not in email:
            flash("Invalid email.", "login")
            return redirect(url_for("login"))
        session['logged_in'] = True
        session['role'] = 'guest'
        session['guest_email'] = email
        return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():
    if not session.get('logged_in'):
        return redirect(url_for("login"))

    if request.method == "POST":
        files = {f: request.files.get(f) for f in ALLOWED}
        if not all(files.values()):
            flash("Please upload all three files", "error")
            return redirect(url_for("dashboard"))

        # type check
        for field, f in files.items():
            ext = os.path.splitext(f.filename)[1].lower()
            if ext not in ALLOWED[field]:
                flash(f"Invalid file type for {field}", "error")
                return redirect(url_for("dashboard"))

        app_id = str(uuid.uuid4())
        ts = datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S")

        save_paths = {}
        for field, f in files.items():
            tag = field.split("_")[0]
            ext = os.path.splitext(f.filename)[1]
            save_path = os.path.join(UPLOAD_FOLDER, f"{app_id}_{tag}_{ts}{ext}")
            f.save(save_path)
            save_paths[tag] = save_path

        # --- backend pipeline on transcript ---
        transcript_path = save_paths['transcript']
        raw_text = extract_text(transcript_path)
        course_list = extract_courses(raw_text)
        scores, expl = score_tracks(course_list)

        recs = [
            { "track": t,
              "score": scores[t],
              "confidence": round(scores[t]/100*0.9+0.1, 2),
              "explanation": expl[t] }
            for t in scores
        ]
        recs.sort(key=lambda r: r['score'], reverse=True)
        result = {
            "applicant_id": app_id,
            "top_pick": recs[0]['track'] if recs else None,
            "recommendations": recs
        }
        with open(os.path.join(RESULT_FOLDER, f"{app_id}.json"), "w", encoding="utf-8") as fh:
            json.dump(result, fh, ensure_ascii=False, indent=2)

        return redirect(url_for("show_result", applicant_id=app_id))

    return render_template("dashboard.html")

@app.route("/result/<applicant_id>")
def show_result(applicant_id):
    path = os.path.join(RESULT_FOLDER, f"{applicant_id}.json")
    if not os.path.exists(path):
        return "Result not found", 404
    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    return render_template("result.html", result=data)

@app.context_processor
def inject_role():
    return dict(current_role=session.get("role", "guest"))

if __name__ == "__main__":
    app.run(debug=True, port=5000)
